# مكتبتي الإبداعية — إصدار الشركات والنسخ الاحتياطي

## الميزات
- قسم مستقل للشركات، وإضافة/تعديل/حذف الشركات.
- مكتبة خاصة بكل شركة؛ كل عنصر يحفظ صورته ووصفه/أمره مع إمكانية النسخ والتعديل والحذف.
- النسخ الاحتياطي يحفظ ملف JSON تلقائياً داخل `Pictures/CreativeLibrary/creative-library-backup.json` على Android 10 وما بعده. على Android 6–9 يطلب إذن التخزين ثم يحفظ في المسار نفسه.
- الاستعادة من ملف JSON عبر منتقي الملفات.
- رقم الإصدار 1.1 ورقم البناء 2 مع الإبقاء على `applicationId` كما هو.

## بناء APK عبر GitHub من ملف ZIP
1. ارفع هذا الأرشيف إلى جذر مستودعك باسم `creative_library_android_project.zip`.
2. ضع ملف سير العمل الموجود داخل `.github/workflows/build-apk-from-zip.yml` في مسار سير العمل نفسه داخل مستودع GitHub.
3. أنشئ أسرار Actions التالية من Settings → Secrets and variables → Actions:
   - `SIGNING_KEYSTORE_BASE64`
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`
4. شغّل Actions باسم `Build Creative Library APK (ZIP source + stable signature)`.
5. حمّل Artifact باسم `creative-library-signed-apk` وثبّت `app-release.apk`.

**التوقيع:** مفتاح التوقيع الدائم منفصل عن هذا المصدر. لا تغيّره بعد أول تثبيت لهذه النسخة؛ كل تحديث لاحق يجب أن يستخدم المفتاح نفسه ومعرّف التطبيق نفسه.
