package com.creativelibrary.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 4102
    private var allowMultipleImages = false
    private val backupSaveRequest = 4104
    private var pendingBackupJson: String? = null
    private var pendingBackupFormat: String = "json"
    private val backupImportRequest = 4105

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveBackup(json: String, fileName: String, format: String) {
            runOnUiThread {
                pendingBackupJson = json
                pendingBackupFormat = format
                try {
                    // Keep the Android system document picker as the save destination chooser.
                    val mime = when (format) {
                        "zip" -> "application/zip"
                        "gz" -> "application/gzip"
                        else -> "application/json"
                    }
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mime
                        putExtra(Intent.EXTRA_TITLE, fileName)
                    }
                    startActivityForResult(intent, backupSaveRequest)
                } catch (e: Exception) {
                    pendingBackupJson = null
                    Toast.makeText(this@MainActivity, "تعذر فتح مدير الملفات: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun openBackupImport() {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "application/zip", "application/gzip", "application/x-gzip", "application/octet-stream"))
                    }
                    startActivityForResult(intent, backupImportRequest)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر فتح مدير الملفات: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("مكتبتي الإبداعية", text))
                Toast.makeText(this@MainActivity, "تم نسخ النص", Toast.LENGTH_SHORT).show()
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.databaseEnabled = true
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url ?: return false
                return if (url.scheme == "file" || url.scheme == "about") false else {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                allowMultipleImages = fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE
                val intent = try {
                    fileChooserParams?.createIntent()
                } catch (_: Exception) {
                    null
                } ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                // Keep the WebView's requested selection mode explicit without overriding
                // its accepted MIME types (the same bridge also serves document attachments).
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, allowMultipleImages)
                return try {
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = null
                    allowMultipleImages = false
                    false
                }
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/www/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == backupSaveRequest) {
            val json = pendingBackupJson
            val format = pendingBackupFormat
            pendingBackupJson = null
            val destination = if (resultCode == Activity.RESULT_OK) data?.data else null
            if (destination != null && json != null) {
                try {
                    val raw = json.toByteArray(Charsets.UTF_8)
                    val output = contentResolver.openOutputStream(destination, "w")
                        ?: throw IllegalStateException("تعذر فتح الملف المحدد")
                    output.use { stream ->
                        when (format) {
                            "zip" -> ZipOutputStream(stream).use { zip ->
                                zip.putNextEntry(ZipEntry("creative-library-backup.json"))
                                zip.write(raw)
                                zip.closeEntry()
                            }
                            "gz" -> GZIPOutputStream(stream).use { it.write(raw) }
                            else -> stream.write(raw)
                        }
                    }
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية المضغوطة في المكان الذي اخترته", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "فشل حفظ النسخة الاحتياطية: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } else if (resultCode != Activity.RESULT_CANCELED) {
                Toast.makeText(this, "لم يتم اختيار مكان للحفظ", Toast.LENGTH_SHORT).show()
            }
        } else if (requestCode == backupImportRequest) {
            val source = if (resultCode == Activity.RESULT_OK) data?.data else null
            if (source != null) {
                try {
                    val bytes = contentResolver.openInputStream(source)?.use { it.readBytes() }
                        ?: throw IllegalStateException("تعذر قراءة الملف")
                    val json = decodeBackupBytes(bytes)
                    webView.evaluateJavascript("window.receiveBackupData(${JSONObject.quote(json)})", null)
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذرت قراءة النسخة الاحتياطية: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        } else if (requestCode == filePickerRequest) {
            val result: Array<Uri>? = if (resultCode == Activity.RESULT_OK && data != null) {
                // Android document/photo pickers may return the selection in data, ClipData,
                // or the standard FileChooserParams result. Read all supported forms.
                val selected = LinkedHashSet<Uri>()
                try {
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data)?.forEach {
                        selected.add(it)
                    }
                } catch (_: Exception) {
                    // Continue with the direct Intent fields below.
                }
                data.data?.let { selected.add(it) }
                data.clipData?.let { clip ->
                    for (index in 0 until clip.itemCount) {
                        clip.getItemAt(index).uri?.let { selected.add(it) }
                    }
                }
                @Suppress("DEPRECATION")
                (data.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { selected.add(it) }
                val uris = selected.toList()
                if (!allowMultipleImages && uris.isNotEmpty()) arrayOf(uris.first())
                else uris.toTypedArray().takeIf { it.isNotEmpty() }
            } else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
            allowMultipleImages = false
        }
    }

    private fun decodeBackupBytes(bytes: ByteArray): String {
        if (bytes.size < 2) throw IllegalArgumentException("الملف فارغ أو غير صالح")
        val decoded = when {
            // ZIP file signature.
            bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte() -> {
                val zip = ZipInputStream(ByteArrayInputStream(bytes))
                zip.use { input ->
                    var entry = input.nextEntry
                    var jsonBytes: ByteArray? = null
                    while (entry != null) {
                        if (!entry.isDirectory && entry.name.lowercase().endsWith(".json")) {
                            jsonBytes = input.readBytes()
                            break
                        }
                        entry = input.nextEntry
                    }
                    jsonBytes ?: throw IllegalArgumentException("لا يحتوي ملف ZIP على نسخة JSON")
                }
            }
            // GZIP signature: 1F 8B
            bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte() ->
                GZIPInputStream(ByteArrayInputStream(bytes)).use { it.readBytes() }
            else -> bytes // Legacy, uncompressed JSON backup.
        }
        return decoded.toString(Charsets.UTF_8)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
