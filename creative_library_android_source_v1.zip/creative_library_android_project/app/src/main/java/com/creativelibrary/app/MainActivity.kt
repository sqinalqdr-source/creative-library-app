package com.creativelibrary.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.content.ContentValues
import android.content.pm.PackageManager
import android.Manifest
import java.io.File
import java.io.FileOutputStream
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 4102
    private val backupPermissionRequest = 4103
    private var pendingBackupJson: String? = null

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveBackup(json: String) {
            runOnUiThread {
                pendingBackupJson = json
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    saveBackupToPictures(json)
                } else if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    saveBackupLegacy(json)
                } else {
                    requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), backupPermissionRequest)
                }
            }
        }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("مكتبتي الإبداعية", text))
                Toast.makeText(this@MainActivity, "تم نسخ النص", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun saveBackupToPictures(json: String) {
        var uri: Uri? = null
        try {
            val relativePath = Environment.DIRECTORY_PICTURES + "/CreativeLibrary/"
            // Replace the previous backup so the folder contains one current backup file.
            contentResolver.delete(
                MediaStore.Files.getContentUri("external"),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",
                arrayOf("creative-library-backup.json", relativePath)
            )
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "creative-library-backup.json")
                put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            uri = contentResolver.insert(MediaStore.Files.getContentUri("external"), values)
                ?: throw IllegalStateException("تعذر إنشاء ملف النسخة الاحتياطية")
            contentResolver.openOutputStream(uri!!, "w")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json) }
                ?: throw IllegalStateException("تعذر فتح ملف النسخة الاحتياطية")
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            contentResolver.update(uri!!, done, null, null)
            pendingBackupJson = null
            Toast.makeText(this, "تم حفظ النسخة في Pictures/CreativeLibrary", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            if (uri != null) runCatching { contentResolver.delete(uri!!, null, null) }
            Toast.makeText(this, "فشل حفظ النسخة الاحتياطية: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveBackupLegacy(json: String) {
        try {
            val folder = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "CreativeLibrary")
            if (!folder.exists() && !folder.mkdirs()) throw IllegalStateException("تعذر إنشاء مجلد Pictures/CreativeLibrary")
            val file = File(folder, "creative-library-backup.json")
            FileOutputStream(file).bufferedWriter(Charsets.UTF_8).use { it.write(json) }
            pendingBackupJson = null
            Toast.makeText(this, "تم حفظ النسخة في Pictures/CreativeLibrary", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "فشل حفظ النسخة الاحتياطية: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == backupPermissionRequest) {
            val json = pendingBackupJson
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && json != null) saveBackupLegacy(json)
            else {
                pendingBackupJson = null
                Toast.makeText(this, "يجب السماح بالوصول للتخزين لحفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.databaseEnabled = true
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url ?: return false
                return if (url.scheme == "file" || url.scheme == "about") false else {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                return try {
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback = null
                    false
                }
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/www/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val result = if (resultCode == Activity.RESULT_OK) {
                val uri = data?.data
                if (uri != null) arrayOf(uri) else WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            } else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
